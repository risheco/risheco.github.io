<?php

class AndroidController extends BaseController {

    public function handshake()
    {
        return "bello";
    }

    public function notificationBroadcast(){
        $s = '{"notifications":
            [
                {
                    "title":"شاه کلید",
                    "text":"اپلیکیشن کاربردی شاه کلید در کافه بازار. کلیک کنید",
                    "icon":"shahkelid",
                    "intent":"market://co.rishe.shahkelid.shahkelid"
                },
                {
                    "title":"Test from web api",
                    "text":"Hiiiiiiiiiiiiiiiiiiiii!!!!!!!!!!",
                },
            ]
        }';
        $rs = array( "notifications" => array(
            array(
                "title"=>"شاه کلید",
                "text"=>"اپلیکیشن کاربردی شاه کلید در کافه بازار. کلیک کنید",
                "icon"=>"shahkelid",
                "intent"=>"market://co.rishe.shahkelid.shahkelid"
            ),
            array(
                "title"=>"Test from web api",
                "text"=>"Hiiiiiiiiiiiiiiiiiiiii!!!!!!!!!!",
            )
        )
        );
        return json_encode($rs);
    }

}
