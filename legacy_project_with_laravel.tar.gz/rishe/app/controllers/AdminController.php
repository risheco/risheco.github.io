<?php

class AdminController extends BaseController {
    public function smsPanelInbox()
    {
        // configuration
        $dbhost 	= "localhost";
        $dbname		= "rishe";
        $dbuser		= "root";
        $dbpass		= "mitikoman";

        // database connection
        $conn = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);

        $sql = "SELECT * FROM smss ORDER BY sdate LIMIT 0,1000";
        $result = $conn->prepare($sql);
        $result->execute();


        //return View::make('admin.smsPanel',array('aa'=>$result->fetchAll()));
    }
}
