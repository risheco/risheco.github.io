<?php

class SMSController extends BaseController {

    public function getSMS()
    {
        $to = Input::get("TO");
        $body = Input::get("BODY");
        $from = Input::get("FROM");

        // configuration
        $dbhost 	= "localhost";
        $dbname		= "rishe";
        $dbuser		= "root";
        $dbpass		= "mitikoman";

        // database connection
        $conn = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);

        // query
        $sql = "INSERT INTO smss (toN,fromN,body,sdate) VALUES (:toN,:fromN,:body,now())";
        $q = $conn->prepare($sql);
        $q->execute(array(':toN'=>$to,':fromN'=>$from,':body'=>$body));
        echo $to.'///'.$from.'\\\\\\'.$body;
    }
}