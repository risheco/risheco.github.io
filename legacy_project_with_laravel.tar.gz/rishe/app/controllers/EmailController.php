<?php

class EmailController extends BaseController {

    public function addEmail()
    {
        $new_email = strtolower(Input::get("newEmail"));

        if(preg_match("/[a-z][a-z0-9\._]+@[a-z\.]+\.[a-z]+/i",$new_email))
        {
            // configuration
            $dbhost 	= "localhost";
            $dbname		= "rishe";
            $dbuser		= "root";
            $dbpass		= "0212526";

            // database connection
            $conn = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);

            $sql = "SELECT count(email) FROM emails WHERE email = :newEmail";
            $result = $conn->prepare($sql);
            $result->bindValue("newEmail",$new_email);
            $result->execute();
            $number_of_rows = $result->fetchColumn();

            if($number_of_rows<1)
            {
                // query
                $sql = "INSERT INTO emails (email) VALUES (:email)";
                $q = $conn->prepare($sql);
                $q->execute(array(':email'=>$new_email,            ));
                return "yes";
            }
        return "no";
        }
    }

}
