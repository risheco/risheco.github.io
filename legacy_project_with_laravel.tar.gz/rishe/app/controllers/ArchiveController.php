<?php

class ArchiveController extends BaseController {

	public function archiveRisheView($i)
	{
        return View::make("archives.rishe.rishe".$i);
	}

}
