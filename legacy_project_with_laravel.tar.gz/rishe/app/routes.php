<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', "HomeController@viewFirstPage");

Route::get('/order',"HomeController@viewOrderPage");

Route::get('/archive/rishe/designs/{i}',"ArchiveController@archiveRisheView");

Route::post('/api/contacts/addemail',"EmailController@addEmail");
Route::get('/api/contacts/addemail',"EmailController@addEmail");
Route::get('/api/handshake',"AndroidController@handshake");
Route::get('/api/notification',"AndroidController@notificationBroadcast");

Route::get('/sms',"SMSController@getSMS");

Route::get('/admin/sms/inbox',"AdminController@smsPanelInbox");

Route::get('sendcookie','HomeController@getcookie');


// ########### // FOR TEST // ########### //
Route::get('123123/popups',function(){
   return View::make('popups');
});

Route::get('info123123/',function(){
    echo phpinfo();
});

Route::get('login','HomeController@loginWithGoogle');
Route::post('login','HomeController@loginWithGoogle');
