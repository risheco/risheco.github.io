<?php 

return array( 
	
	/*
	|--------------------------------------------------------------------------
	| oAuth Config
	|--------------------------------------------------------------------------
	*/

	/**
	 * Storage
	 */
	'storage' => 'Session', 

	/**
	 * Consumers
	 */
	'consumers' => array(

		/**
		 * Facebook
		 */
        'Facebook' => array(
            'client_id'     => '',
            'client_secret' => '',
            'scope'         => array(),
        ),

        /**
         * Google
         */
        'Google' => array(
            'client_id'     => '512918607224-lm7t33p88290qvndvnob1o0votfatd7v.apps.googleusercontent.com',
            'client_secret' => 'nb2I-zfnGszRIH7_K-AlnK6l',
            'scope'         => array(),
        ),

	)

);