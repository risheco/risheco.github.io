<html>
<body>

<br>######################################<br>
@foreach($aa as $a)
    @foreach($a as $b)
        {{$b}} <br>-------------------<br>
    @endforeach
    ##############################
@endforeach
</body>
</html>