<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="/css/FirstPage.css" />
    <title>Rishe - ریشه</title>
    <meta charset="utf-8" >
    <meta name="description" content="شرکت توسعه نرم افزار ریشه تولید کننده نرم افزار و طراحی وبسایت" />
    <meta name="keywords" content="طراحی وب ، تولید ، طراحی ، اندروید ، طراحی نرم افزار اندروید ، نرمافزار ، ios،" />
</head>
<body>
<div class="menu">
        <span class="menu">
            ریشه
        </span>
        <span class="menu">
            نمونه کار
        </span>
        <span class="menu">
            تماس با ما
        </span>
</div>
<div class="logo"></div>
<h1>ریشه</h1>
<div class="footer"><span>Risho.co شرکت توسعه نرم افزار ریشه </span></div>

<div class="container">
    <span class="title"> خدمات ما </span> <br>
    <div class="links">
        <button class="link">طراحی سایت</button>
        <button class="link">اندروید</button>
        <button class="link">سایر خدمات</button>
    </div>

</div>

</body>
</html>