<html>
<head>
	<title>شرکت توسعه نرمافزار ریشه</title>
	<meta charset="utf-8" >
	<meta name="description" content="شرکت توسعه نرم افزار ریشه تولید کننده نرم افزار و طراحی وبسایت" />
		<meta name="keywords" content="طراحی وب ، تولید ، طراحی ، اندروید ، طراحی نرم افزار اندروید ، نرمافزار ، ios،" />
		<link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
<a class="top"><span class='glyphicon top'></span></a>
<div class="first">
<div class="fade">
	<div class="logo"></div>
	<p>ریشه</p>
	<a href="#"id="description">درباره ما</a>
	<a href="#" id="web">طراحی وبسایت</a>
	<a href="#" id="mobile">طراحی نرم افزار موبایل</a>
	<a href="#" id="contact">تماس با ما</a>
</div>
</div>
<div class="description">
<div class="fade"  style="opacity:1;">
<p>امروزه آمار ها نشان از افزایش تعداد دیوایس های هوشمند میدهند ؛ به طوری که شرکت گوگل پیشبینی کرده است که تا سال 2017 حدود 20 میلیارد دیوایس هوشمند در دنیا وجود خواهد داشت پس حضور در دنیای تکنولوژی برای همه بخصوص کسانی که به دنبال یک کسب و کار موفق هستند امری اجتناب ناپذیر است تیم طراحی ریشه با استفاده از متد های روز و دانش کافی آماده است تا شما را در این مسیر یاری نماید</p>
<img src="12.png">

</div>

</div>

<div class="web">
<div class="fade" >
<h2>طراحی وب</h2>
<p>
	یک طراحی وب خوب میتواند به رشد یک موضوع بسیار کمک کند .  طراحی وب اصولی ترکیبی از روانشناسی و علم تجارت و کامپیوتر است .<br>با توجه به رشد سریع تکنولوژی و در دسترس بودن اینترنت  ، پر واضح است که یکی از بازار های بزرگ دنیا در حال حاضر بازار اینترنت است . <br> تیم طراحی <strong style="color:#058;font-size:1.3em;"> ریشه </strong> امیدوار است با توجه به دارا بودن افراد متخصص و با تجربه بتواند نیاز های شما را در این زمینه تامین نماید .
</p>
<h1>http://www.</h1>
</div>
</div>

<div class="mobile">
<div class="fade">
	<p>
		دسترسی سریع ، لذت بخش بودن کار با آنها و قابل حمل و نقل بودنشان موجب شده تا کمتر خانواده ای را ببینیم که یک موبایل یا تبلت هوشمند نداشته باشد ، تیم طراحی اپلیکیشن ریشه به شما در طراحی یک نرم افزار کار آمد و محبوب کمک خواهد کرد
	</p>
	<img src="/devices.png">
	
</div>
</div>

<div class="contact">
<div class="fade">
<div class="logo"></div>
<p>	Email : <a href="mailto:risheco@gmail.com">risheco@gmail.com</a></p>
<p>	Facebook : <a href="https://facebook.com/rishe.co">facebook.com/rishe.co</a></p>
	<p>Tel : 1233456689</p>
</div>
</div>

<script src="/js/jquery-1.9.1.js"></script>
<script src="/js/jquery.easing.1.3.js"></script>
<script>
	$('body').animate({'scrollTop':'0px'});
		var position = $(window).scrollTop();
	$(window).scroll(function(){

		fades = document.getElementsByClassName('fade');
		// for (var i = fades.length - 1; i >= 0; i--) {
		// 	if(fades[i].style.opacity != 0){
		// 		fades[i].style.position = "fixed";
		// 	}
		// };
		var Yscroll = $(window).scrollTop();
		var height = window.innerHeight;
		var startPoint = $(window).scrollTop();
		console.log($('div.first').offset().top);
		if(Yscroll<height){					 	
	 		dif = Yscroll - height ;
			// $('div.first').stop(true,true);
			$('div.description').animate({'top':'150%'},600,'easeOutQuad');
			$('div.mobile').animate({'top':'-150%'},600,'easeOutQuad');
			
		 	$('div.first').stop(true,true).animate({'top':"0px"},600,'easeOutQuad');
		 	$('div.description').css('top','200%');
		 	$('div.web').css('top','300%');
		 	$('div.mobile').css('top','400%');
		 	$('div.contact').css('top','500%');

			
		}
		else if(Yscroll>=height && Yscroll <=(2*height)){
			if($('div.first').offset().top != '-150%'){
				dif = -(Yscroll - height)*0.75 ;
				$('div.first').animate({'top': '-150%'},800,'easeOutQuad');
				$('div.mobile').animate({'top':'-150%'},600,'easeOutQuad');
				
				$('div.description').stop(true,true).animate({'top':0},600,'easeOutQuad');
				
		 	
				
			}
		}
		else if(Yscroll>=height*2 && Yscroll <(3*height)){
			if($('div.first').offset().top != '-150%'){
				dif = -(Yscroll - height)*0.75 ;
				$('div.first').animate({'top': '-150%'},800,'easeOutQuad');
				$('div.description').animate({'top':'-150%'},600,'easeOutQuad');
				$('div.mobile').animate({'top':'-150%'},600,'easeOutQuad');
				
				$('div.web').stop(true,true).animate({'top':0},600,'easeOutQuad');
				
			}
		}		
		else if(Yscroll>height*3 && Yscroll <(4*height)){
			if($('div.web').offset().top != '-150%'){
				dif = -(Yscroll - height)*0.75 ;
				$('div.first').animate({'top': '-150%'},800,'easeOutQuad');
				$('div.description').animate({'top':'-150%'},600,'easeOutQuad');
				$('div.web').animate({'top':'-150%'},600,'easeOutQuad');
				$('div.mobile').animate({'top':'-150%'},600,'easeOutQuad');
				
				$('div.mobile').stop(true,true).animate({'top':0},600,'easeOutQuad');
			}
		}
		else{
			if($('div.first').offset().top != '-150%'){
				dif = -(Yscroll - height)*0.75 ;
				$('div.first').animate({'top': '-150%'},800,'easeOutQuad');
				$('div.description').animate({'top':'-150%'},600,'easeOutQuad');
				$('div.web').animate({'top':'-150%'},600,'easeOutQuad');
				$('div.mobile').animate({'top':'-150%'},600,'easeOutQuad');
				
			}	
		}	
		

	});

	$('a').click(function(){
		if($(this).attr('id') == 'description'){
		$('body').animate({'scrollTop':window.innerHeight});
	}
	else if($(this).attr('id') == 'web'){
		$('body').animate({'scrollTop': (window.innerHeight)*2 +5 });
	}
	else if($(this).attr('id') == 'mobile'){
		$('body').animate({'scrollTop':(window.innerHeight)*3 + 5});
	}
	else if($(this).attr('id') == 'contact'){
		$('body').animate({'scrollTop':(window.innerHeight)*5});
	}
	});

	$(document).keydown(function(event){
 
	var keycode = (event.keyCode ? event.keyCode : event.which);
	console.log(keycode);
	if(keycode == '38'){
		$('body').animate({'scrollTop':'-='+(window.innerHeight +5 )});
	}
	else if(keycode == '40'){
		$('body').animate({'scrollTop':'+='+(window.innerHeight +5 )});
	}

 
});
	$('a.top').click(function(){
		$('body').animate({'scrollTop':'0px'},1000);	
	});
</script>
</body>
</html>