<html>
<head>
<title>شرکت توسعه نرم افزار ریشه</title>
<meta charset="utf-8">
</head>
<body>
<div class="popup">
<div class="bg"></div>
<div class="content">
لطفا جهت سفارش با این شماره تماس بگیرید<br>
<strong>09353339869</strong>
<br>
<br>
<br>

<b>بستن</b>
</div>
</div>


<div class="fluid">
<div class="first" style="text-align:center;font-size:3em; position:absolute; width:100%; margin-top:15.6%;">از ریشه شروع کن ؛<br><strong>برو بالا</strong>
<ul>
<li class="flat-icon" data-color="#2980b9"> f </li>
<li class="flat-icon" data-color="#3498db"> t </li>
<li class="flat-icon phone" data-color="#f39c12" ><span class="glyphicon glyphicon-earphone"></span></li>
<li class="flat-icon" data-color="#9b59b6"><span class="glyphicon glyphicon-envelope"></span></li>
</ul>
</div>
</div>
<div class="fluid">
<div class="text" style="text-style:justify;direction:ltr;position:absolute;margin-top:1.6%;font-size:1.2em;">
    <h2 style="margin-left:20.6%;">طراحی وبسایت</h2>
    	<p style="margin-left:2.6%;direction:rtl;">
       		یک طراحی وب خوب میتواند به رشد یک موضوع بسیار کمک کند . طراحی وب اصولی ترکیبی از روانشناسی و علم تجارت و کامپیوتر است .
با توجه به رشد سریع تکنولوژی و در دسترس بودن اینترنت ، پر واضح است که یکی از بازار های بزرگ دنیا در حال حاضر بازار اینترنت است . 
تیم طراحی ریشه امیدوار است با توجه به دارا بودن افراد متخصص و با تجربه بتواند نیاز های شما را در این زمینه تامین نماید .
        </p>
    </div>


</div>
<div class="fluid">
    <div class="text" style="position:absolute;right:2.6%;margin-top:1.6%;font-size:1.2em;">
    <h2>اپلیکیشن موبایل</h2>
    	<p>
       دسترسی سریع ، لذت بخش بودن کار با آنها و قابل حمل و نقل بودنشان موجب شده تا کمتر خانواده ای را ببینیم که یک موبایل یا تبلت هوشمند نداشته باشد ، تیم طراحی اپلیکیشن ریشه به شما در طراحی یک نرم افزار کار آمد و محبوب کمک خواهد کرد
        </p>
    </div>
</div>

<div class="fluid" id="last">
<div class="up" id="app"></div>
<span class="company">شرکت توسعه نرم افزار ریشه</span>
</div>
<script src="/js/jquery-1.11.1.js"></script>
<script src="/js/jquery.flatshadow.min.js"></script>
<script src="/js/flowtype.js"></script>
	<style>
	@font-face{
    font-family: 'Mitra';
    src: local("Mitra"),local("B Mitra"), local("F Mitra") , url('/fonts/BMitra.eot?#iefix') format('embedded-opentype'),
          url('/fonts/BMitra.woff') format('woff'),
          url('/fonts/BMitra.ttf') format('truetype');
}
	body{
		background:url(/rootcoweb.png);
		background-size:auto 400%;
		background-position:center top;
		height:100%;;
		background-repeat:no-repeat;
		background-color:#1abc9c;
		direction:rtl;
		padding:0px;
		margin:0px;
		font-family:tahoma;
		
	}
	div.fluid{
		width:100%;
		height:100%;
		color:#fff;
		font-family:'Mitra';
	}
	div.up{
		width:150px;
		height:60px;
		background:url(go-up.png);
		background-repeat:no-repeat;
		background-size:100% 100%;
		position:fixed;
		top:1.6%;
		float:right;
		cursor:pointer;
	}
	p{
		width:35%;
	}
	ul{
		padding:0px;
		margin:auto;
	}
	li{
		font-size:0.8em;
	}
	li:hover{
		cursor:pointer;
	}
	.flat-icon {
    display:inline-block;
    font-weight: bold;
    display: inline-block;
    overflow: hidden;
    margin:auto;
	border-radius:50%;
	width:55px;
	height:55px;
	}
	div.bg{
		position:fixed;
		width:100%;
		height:100%;
		background:rgba(55,55,55,0.6);
		padding:0px;
		margin:0px;
	}
	div.content{
		background:#fff;
		position:fixed;
		width:50%;
		height:50%;
		border-radius:3px;
		border:1px solid #454545;
		top:25%;
		right:25%;
		text-align:center;
		font-size:1.2em;
		line-height:2;
		z-index:99999;
	}
	div.popup{
		display:none;
	}
	span.company{
		font-size:2em;
		text-align:center;
		position:absolute;
		width:100%;
	}
	b{
		background:#e74c3c;
		padding:15px;
		padding-left:25px;
		padding-right:25px;
		border-radius:2px;
		color:#fff;
		border-bottom:3px solid #c0392b;
		text-shadow:-1px -1px #900;
	}
	b:hover{
		border:none;
		cursor:pointer;
	}
	@font-face {
  font-family: 'Glyphicons Halflings';

  src: url('fonts/glyphicons-halflings-regular.eot');
  src: url('fonts/glyphicons-halflings-regular.eot?#iefix') format('embedded-opentype'), url('fonts/glyphicons-halflings-regular.woff') format('woff'), url('fonts/glyphicons-halflings-regular.ttf') format('truetype'), url('fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular') format('svg');
  

}
.glyphicon {
  position: relative;
  top:5px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: normal;


  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
	.glyphicon-earphone:before {
  content: "\e182";
}
.glyphicon-envelope:before {
  content: "\2709";
}
@media(max-width : 480px){
		p{
			width:98%;
			margin-left:auto;
		}
		div.fluid{
			padding-right:5px;
			margin:auto;
			background:rgba(55,55,55,0.5);
		}
		div.first{
			font-size:2em !important;
			margin-top:35% !important;
		}
	}

		</style>
    <script>
	//first scroll to down on load ;
	var x = $('div#last').offset();
	$('body').animate({'scrollTop':x['top']});
	$(document).ready(function(){
		var offset = (window.innerWidth - 150 )/2 ;
		var topOffset = (window.innerHeight - $('.company').height())/2 - 45;
			$('div.up').css('right',offset);
			$('.company').css('margin-top',topOffset);
		});
	//end of scrolling 
	
	
	//go up button click function 
	$('div.up').click(function(){
			var top = $('body').scrollTop();
			if(top>0 && top < window.innerHeight){
				
			}
			else if(top >= window.innerHeight && top < window.innerHeight * 1.5){
				$('body').animate({'scrollTop':0});
			}
			else if(top > window.innerHeight *1.5&& top < window.innerHeight * 2.5){
				$('body').animate({'scrollTop':window.innerHeight});
			}
			else if(top > window.innerHeight *2.5&& top < window.innerHeight * 3.5){
				$('body').animate({'scrollTop':window.innerHeight*2});
			}
			
			
			
		});
		
		//end go up button
		
		
		//check if we onthe top disable the go up button

		Scroll = function(){
				var top = $('body').scrollTop();
				if(top < window.innerHeight /2){

					$('div.up').fadeOut(600);
				}
				else{
					$('div.up').fadeIn();
				}
			};
			$(window).scroll(Scroll);
		
		//end of show and off the button script
		
		//flat shadow scripts
			$(".flat-icon").flatshadow({
        		angle: "SE",
            	fade: false,
       			boxShadow: false // Accept full 6 digit hex color (#000000),

			});
			
		//end 
		//show phone number 
			$('.phone').click(function(){
				$('div.popup').fadeIn(600);
					
				});
				
				
			$('div.bg').click(function(){
				$('div.popup').hide(600);
					
				});
			$('b').click(function(){
				$('div.popup').hide(600);
					
				});
		//end of show fone number function
		
		//flowType 
		$('.text').flowtype({
   				minimum   : 500,
   				maximum   : 1200,
   				minFont   : 6,
   				maxFont   : 24,
   				fontRatio : 30
			});

		//end of flow type function
    </script>
</body>
</html>