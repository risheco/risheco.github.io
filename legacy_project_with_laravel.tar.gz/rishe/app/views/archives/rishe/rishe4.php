<!-- color needed //#5a1728 -->

<html>
<head>
	<title>شرکت توسعه نرمافزار ریشه</title>
	<meta charset="utf-8">
	<link rel="icon" href="/img/rishe-logo-14.png">

</head>
<body>
<div class="load">
<img src="/img/load.gif">
	<div id="BAR" class="bar">
		<small style="font-size:0.6em;"></small>
	</div>
</div>
<div id="fullpage">
	<div id="one"class="section">
		<div class="menu">
		<ul dir="rtl">
			<li><a href="#about">درباره ما</a></li>
			<li><a href="#web">طراحی وبسایت</a></li>
			<li><a href="#mobileApp">طراحی نرم افزار موبایل</a></li>
			<li><a href="#osApp">طراحی برنامه های سیستم عامل</a></li>
			<li><a href="#contact">تماس با ما</a></li>
		</ul>
		</div>
		<div class="text">
		
		<div class="content">
			<h1>گروه طراحی و توسعه نرم افزار ریشه</h1>
			<h2>یک گروه کوچک که کارهای بزرگ میکنه</h2>
		</div>
		<section class="logo"></section>
		</div>
	</div>


	<div id="two" class="section">
		<div class="aboutUs">
		<div class="img">
			<p class="tag"><strong>طراح و برنامه نویس وب</strong><br><br></p>
			<img src="/img/hossein.png"><br>
			<strong>حسین خلیلی</strong>
		</div>
		<div class="img">
		<p class="tag"><strong>برنامه نویس اندروید</strong><br><br></p>
			<img src="/img/bardia.png"><br>
			<strong>بردیا حیدری نژاد</strong>
		</div>
		<div class="img">
		<p class="tag"><strong >برنامه نویس وب</strong><br><br></p>
			<img src="/img/hamid.png"><br>
			<strong>حمید فیض آبادی</strong><br>
		</div>
		<div class="img">
		<p class="tag"><strong>برنامه نویس کامپیوتر</strong><br><br></p>
			<img src="/img/hesam.png"><br>
			<strong>حسام رعیتنیا</strong>
		</div>
		</div>
	</div>
	<div id="three" class="section">
		<!-- <img class="imac"src="img/imac.png"> -->
		<div class="web">
		<h1>طراحی وبسایت</h1>
		<div id="cheap" class="pack">
			<h2>بسته ارزان قیمت</h2>
			<p>بسته ارزان قیمت برای آنهایی مناسب است که به دنبال راه اندازی یک کسب و کار کوچک یا یک وبسایت شخصی معمولی میباشند این بسته از سیستم های مدیریت محتوای رایگان مانند joomla یا wordpress بهره میبرد </p>
			<a href="#pack1">توضیحات بیشتر</a>
		</div>

		<div id="pro" class="pack">
			<h2>بسته حرفه ای</h2>
			<p>این بسته برای کسانی که به دنبال یک وبسایت حرفه ای هستند مناسب است و کاملا توسط طراحان و برنامه نویسان ما اجرا میگردد که دارای امنیت مناسب و کیفیت بالاست</p>
			<a href="#pack1">توضیحات بیشتر</a>
		</div>
		</div>
	</div>
	<div id="four" class="section">
		<div class="app">
			<h1>طراحی اپلیکیشن موبایل</h1>
			<div class="images">
				<img id="iphone" src="/img/iphone.png">
				<img id="nexus" src="/img/nexus.png">
			</div>
			<div class="apptext">
دسترسی سریع ، لذت بخش بودن کار با آنها و قابل حمل و نقل بودنشان موجب شده تا کمتر خانواده ای را ببینیم که یک موبایل یا تبلت هوشمند نداشته باشد ، تیم طراحی اپلیکیشن ریشه به شما در طراحی یک نرم افزار کار آمد و محبوب کمک خواهد کرد
			</div>
		</div>
	</div>
	<div id="five" class="section">
		<div class="os">
			<div class="imgs">
			<img src="/img/osx.png">
			<img src="/img/win.png">
			<img src="/img/linux.png">
		</div>
		<div class="text">
			امروزه لزوم استفاده از کامپیوتر در ادارات و شرکت ها با توجه به نقش اساسی آن انکار ناپذیر است .<br>
			هر چند که دنیا در حال حرکت به سمت برنامه های تحت وب است اما نمیتوان نقش برنامه های تحت سیستم عامل نظیر برنامه های حسابداری یا مدیریتی را نادیده گرفت<br>
			تیم ریشه میتواند به شما در دست یافتن به برنامه ی مورد نظرتان یاری برساند 
		</div>
		</div>
	</div>
	<div id="six" class="section">
	<div class="contact">
	<p><img src="/rishe-logo.png"></p>
		<p>Email : <small>info@rishe.co</small></p>
		<p>Tell : <small>123-12345678</small></p>
		</div>
	</div>
</div>
   


<style type="text/css">
@font-face{
    font-family: 'Mitra';
    src: local("Mitra"),local("B Mitra"), local("F Mitra") , url('/fonts/BMitra.eot?#iefix') format('embedded-opentype'),
          url('/fonts/BMitra.woff') format('woff'),
          url('/fonts/BMitra.ttf') format('truetype');
}
	body{
		background-color: #ecf0f1;
		padding:0px;
		margin: 0px;
		font-family: sans-serif;

	}
	div.load{
		position: fixed;
		background-color: #2c3e50;
		color: #fff;
		font-size: 40px;
		height: 100%;
		width: 100%;
		text-align: center;
		z-index: 9999;

	}
	div.load img{
		margin: auto;
		margin-top: 15%;
		padding: 0px;
		height: 15%;
		width: auto;
		border:solid 2px #fff;
	}

	div.section{
		margin-top: 0px;
		width: 100%;

	}
	div.section#one{
		background-color: #3498db;
		
		width: 100%;
		color: #fff;
		
	}
	div.menu{
		text-align: center;
		color: #fff;
		position: static;
		width: 85%;
		margin: auto;
		padding-top: 1.6%;
		overflow: visible;
	}
	div.menu ul{
		list-style: none;
		padding: 0px;
		background-color: #34495e;
		background-repeat: no-repeat;
		background-size: 64px 64px;
		background-position: center;
		border-radius: 10px;
		text-align: center;

	}
	div.menu ul li{
		display: inline-block;
		line-height: 35px;
		margin-left: 25px;
		padding-right: 4px;
		padding-left: 4px;
		margin-top: 5px;
		margin-bottom: 5px;
		background-color: #2c3e50;
		border-radius: 10px;
		font-family: tahoma;
	}
	div.menu ul li:hover{
		background-color: #bdc3c7;
		cursor:pointer;
		color: #333;
	}
	div.menu ul li a{
		text-decoration: none;
		color: inherit;
	}
	.logo{
		width: 25%;
		background-image: url(/rishe-logo.png);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		background-position: 0px -20px;
		display: inline-block;
		float: left;
		border: 3px solid #fff;
		border-radius: 50%;
		padding: 0px;
		z-index: -999;
		margin-left: 1.6%;

	}
	div.content{
		width: 55%;
		font-family: 'Mitra';
		font-size: 1.5em;
		float: left;
		display: inline-block;
		direction: rtl;
		text-align: right;
		margin-right:-150px;
		opacity:0;
	}
	div.text{
		margin: auto;
		width: 85%;
		text-align: center;
		padding: 0px;
		margin-top: 0px;
	
	}
	div.aboutUs{
		height: 85%;
		bottom: 0px;
		width: 100%;
		text-align: center;
		color: #fff;
		font-family: tahoma;
		position: absolute;
	}
	div.img img{
		width: 100%;
		height: auto;
		border-radius: 50%;
		border:solid 2px #ecf0f1;
		min-width: 85px;
		margin-left: 15px;
		opacity: 0;
	}
	div.img{
		margin-left: 1.6%;
		display: inline-block;
		width: 15%;
	}
	p.tag{
		background: #2c3e50;
		padding: 1em;
		font-size: 1em;
		opacity: 0;
	}
	div#three{
		background-image: url(/img/imac.png);
		background-size: 100% auto;
		background-repeat: no-repeat; 
		background-attachment: fixed;
	}
	div#three img.imac{
		width: 100%;
		margin-left: -100%;
	}
	div.pack{
		position: absolute;
		display: inline-block;
		width: 20%;
		margin-left: 40%;
		background: #fff;
		border:solid 1px #bdc3c7;
		border-radius: 5px;
		text-align: center;
		margin-top: 5%;
		font-family: tahoma;
		padding: 15px;
		min-height: 15%;
		opacity: 0;
		direction: rtl;
	}
	div.pack h2{
		color: #d35400;
	}
	div.pack a{
		background-color: #e74c3c;
		color: #fff;
		box-shadow: 0px 2px 0px #c0392b;
		text-shadow:-1px -1px #2c3e50;
		text-decoration: none;
		padding: 5px;
		padding-left: 10px;
		padding-right: 10px;
	}
	div.pack a:hover{
		opacity: 0.9;
	}
	div.pack a:active{
		box-shadow: 0px -2px 0px #c0392b;
		text-shadow:1px 1px #2c3e50;
	}
	div#pro{
		margin-left: 68%;
	}
	div#three h1{
		margin-left: 45%;
		margin-top: 0px;
		padding-top: 25px;
		font-family: 'Mitra';
		color: #fff;
	}
	div.app{
		color: #fff;
		font-size: 1.2em;
		padding-top: 5%;
		font-family: 'Mitra';
	}
	div.app h1{
		text-align: center;
	}
	div.app div{
		float: left;
		width: 45%;
	}
	div.app img{
		width: 35%;
		height: auto;
		margin-left: 0%;
	}
	div.app div.images{
		position: absolute;
		width: 45%;
		right: 0;
	}
	div.app div.apptext {
		width: 35%;
		margin-left: 1.6%;
		direction: rtl;
		font-size: 1.2em;
	}
	div.os div.imgs{
		text-align: center;
	}
	div.os img{
		opacity: 0;
		width: 10%;
		margin-left: 3%;
		padding-top: 5%;
	}
	div.os div.text {
		color: #fff;
		font-size: 1.5em;
		direction: rtl;
		font-family: 'Mitra';
		padding-top: 5%;
	}
	div.contact{
		padding-top: 5%;
	}
	
	div.contact img{
		width: 15%;
	}
	div.contact p{
		text-align: center;
		color: #fff;
		font-size: 18px;
	}
</style>
<!-- <script src="js/jquery-1.11.1.js"></script>
<script src="js/jquery-ui-1.9.2.custom.min.js"></script>
 --><link rel="stylesheet" type="text/css" href="css/jquery.fullPage.css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>

<script src="/js/jquery.flatshadow.min.js"></script>
<script src="/js/flowtype.js"></script>
	<script type="text/javascript" src="/js/jquery.slimscroll.min.js"></script>

	<script type="text/javascript" src="/js/jquery.fullPage.js"></script>
	
<script>
	$(document).ready(function(){
		$('div.load').fadeOut();
		$('div#three').css('background-position','-'+(window.innerWidth) +'px');
	})
</script>

<script type="text/javascript">
	function blurElement(element, size){
            var filterVal = 'blur('+size+'px)';
            $(element)
              .css('filter',filterVal)
              .css('webkitFilter',filterVal)
              .css('mozFilter',filterVal)
              .css('oFilter',filterVal)
              .css('msFilter',filterVal);
        }

   	blurElement('section',10);
   	function hideBlur(element){ var time = setInterval(blurElement(element),1000); }


	var firsText = document.getElementsByClassName('text')[0];
	var margin = (window.innerHeight - firsText.offsetHeight)/4 ;
	firsText.setAttribute('style','margin-top:'+ margin + 'px;')

	var logoWidth = document.getElementsByClassName('logo')[0].offsetWidth ; 
	
	document.getElementsByClassName('logo')[0].setAttribute('style','height:'+logoWidth+'px;');

	//animate 
	var text  = document.getElementsByClassName('content')[0];
	var logo = document.getElementsByClassName('logo')[0];
	text.setAttribute('style','margin-right:-150px;opacity:0;');

	function move(elem) {
	  var left = 0 
	  function frame() {
	    left++  // update parameters

	    var opacity = Number(window.getComputedStyle(text).opacity) + 0.007;
	    var margin = parseInt(window.getComputedStyle(text).marginRight) + 1;
	
	    text.setAttribute('style','margin-right:'+margin+'px;'+'opacity:'+opacity+';'); // show frame
	    if (left == 150)  // check finish condition
	      clearInterval(id)
	  }
	  var id = setInterval(frame, 10) // draw every 10ms
	}
	move();
	//end



	window.onresize = function(){
	var logoWidth = document.getElementsByClassName('logo')[0].offsetWidth ; 
	console.log(logoWidth);
	document.getElementsByClassName('logo')[0].setAttribute('style','height:'+logoWidth+'px;');
	}
	$('body').flowtype({
   				minimum   : 500,
   				maximum   : 1200,
   				minFont   : 12,
   				maxFont   : 24,
   				fontRatio : 85
			});



	//loading
		


	//end
	</script>
	<script>
			$(document).ready(function() {
				
    $('#fullpage').fullpage({
        verticalCentered: false,
        resize : true,
        sectionsColor : ['#3498db','#e74c3c','#2ecc71','#34495e','#e67e22','#16a085'],
        anchors:['home', 'about','web','mobileApp','osApp','contact'],
        scrollingSpeed: 700,
        easing: 'easeInQuart',
        menu: true,
        navigation: true,
        navigationPosition: 'right',
        navigationTooltips: ['صفحه اصلی', 'درباره ما','طراحی وبسایت','طراحی نرم افزار موبایل','طراحی نرم افزار سیستم عامل','تماس با ما'],
        slidesNavigation: true,
        slidesNavPosition: 'bottom',
        loopBottom: true,
        loopTop: false,
        loopHorizontal: true,
        autoScrolling: true,
        scrollOverflow: false,
        css3: false,
        paddingTop: '0px',
        paddingBottom: '0px',
        normalScrollElements: '#element1, .element2',
        normalScrollElementTouchThreshold: 2,
        keyboardScrolling: true,
        touchSensitivity: 15,
        continuousVertical: false,
        animateAnchor: true,
        sectionSelector: '.section',
        slideSelector: '.slide',

        //events
        onLeave: function(index, nextIndex, direction){
        	if(index == 2){
        		$('div.aboutUs div.img img').animate({'opacity':0,'margin-left':'15px'},700);
        		$('div.aboutUs div.img p').delay(500).animate({'opacity':0});
        	}
        	if(index == 3){
        		$('div#three	').animate({'background-position':'-'+(window.innerWidth) +'px'},700);
        		$('div.pack').animate({'opacity':0});
        	}
        	if(index == 4){
        		 $('div#four img').animate({'margin-left':'0%'},700);
        		 
        	}
        	if(index == 5){
        		 $('div#five img').animate({'opacity':0},700);
        		 
        	}
        },
        afterLoad: function(anchorLink, index){
        	if(anchorLink == 'about'){
        		$('div.aboutUs div.img img').animate({'opacity':1,'margin-left':'0px'},700);
        		$('div.aboutUs div.img p').delay(500).animate({'opacity':1});
        	}
        	if(anchorLink == 'web'){
        		 $('div#three').animate({'background-position':'-'+(window.innerWidth/2) +'px'},700);
        		 $('div.pack').delay(700).animate({'opacity':1});
        	}
        	if(anchorLink == 'mobileApp'){
        		 $('div#four img').animate({'margin-left':'-10%'},700);
        		 
        	}
        	if(anchorLink == 'osApp'){
        		 $('div#five img').animate({'opacity':1},700);
        		 
        	}
        },
        afterRender: function(){},
        afterResize: function(){},
        afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex){},
        onSlideLeave: function(anchorLink, index, slideIndex, direction){}
    });
});
	</script>
</body>
</html>