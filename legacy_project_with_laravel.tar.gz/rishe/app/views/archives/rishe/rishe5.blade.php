<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="/css/style5.css" />
    <title>Rishe - ریشه</title>
    <meta charset="utf-8" >
    <meta name="description" content="شرکت توسعه نرم افزار ریشه تولید کننده نرم افزار و طراحی وبسایت" />
    <meta name="keywords" content="طراحی وب ، تولید ، طراحی ، اندروید ، طراحی نرم افزار اندروید ، نرمافزار ، ios،" />
</head>
<body id="body">

<div id="right" onmouseover="drawRight()" onmouseout="undrawRight()">
    <div class="shadow" id="shadow_right"></div>
    <div class="container" id="container_right">
        <h4>خدمات ما:</h4> <hr>
        <li>طراحی سایت</li>
        <li>اندروید</li>
        <li>وب سرویس</li>
        <li>سرویس های sms</li>
        <li>نرم افزار های اتوماسیون</li>
    </div>
</div>

<div id="left" onmouseover="drawLeft()" onmouseout="undrawLeft()">
    <div class="shadow" id="shadow_left"></div>
    <div class="container" id="container_left">
        <h4>سرویس های ما:</h4> <hr>
        <li>LearnHub</li>
        <li>TabletYab</li>
        <li>Pinger</li>
        <li>Url Shortener</li>
        <li>اسم و فامیل</li>
        <li>پلیس مخفی</li>
        <li>پدیکا</li>
    </div>
</div>

<div id="center">
    <button class="open_drawer" id="btn_left" onmouseover="drawLeft()" onmouseout="undrawLeft()">سوریس ها</button>
    <button class="open_drawer" id="btn_right" onmouseover="drawRight()" onmouseout="undrawRight()">خدمات</button>
    <div class="title">
        <img src="/img/rishe-logo.png">
        <h2>گروه افزاری ریشه </h2>
        <h1>ریشه</h1>

    </div>

    <div class="footer">
        <h3>Rishe co</h3>
    </div>
</div>
<script>
    function drawRight() {
        document.getElementById("body").setAttribute("style","margin-right:0px;margin-left:-560px");
    }
    function undrawRight() {
        document.getElementById("body").setAttribute("style","margin-right:-280px;margin-left:-280px");
    }
    function drawLeft() {
        document.getElementById("body").setAttribute("style","margin-left:0px;margin-right:-560px");
    }
    function undrawLeft() {
        document.getElementById("body").setAttribute("style","margin-left:-280px;margin-right:-280px");
    }

</script>
</body>
</html>