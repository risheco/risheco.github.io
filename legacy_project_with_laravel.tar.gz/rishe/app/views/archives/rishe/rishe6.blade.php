<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="stylesheet" href="../css/style6.css" />
    <title>Rishe - ریشه</title>
    <meta charset="utf-8" >
    <meta name="description" content="شرکت توسعه نرم افزار ریشه تولید کننده نرم افزار و طراحی وبسایت" />
    <meta name="keywords" content="طراحی وب ، تولید ، طراحی ، اندروید ، طراحی نرم افزار اندروید ، نرمافزار ، ios،" />
</head>

<body>
<div id="main">
    <div id="header">
        <div class="logo">
            <img src="../rishe-logo.png" id="header-logo">
        </div>
        <div class="title">
            <h2>گروه نرم افزاری</h2>
            <h1>ریشه</h1>
        </div>
    </div>
    <div class="services">
        <div class="item">
            <img src="http://gethealthapp.com/img/home_platform/website-showcase.png" class="item">
        </div>
    </div>
</div>
</body>