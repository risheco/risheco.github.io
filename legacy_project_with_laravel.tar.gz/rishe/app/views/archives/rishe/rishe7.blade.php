<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="/css/style7.css">
    <link rel="stylesheet" type="text/css" href="/css/homepageStyle.css">
    <link rel="stylesheet" type="text/css" href="/css/animate.css">
    <script type="text/javascript" src="/js/jquery-2.1.1.min.js"></script>
    <script type="application/javascript" src="/js/jquery.gsap.min.js"></script>
    <script type="application/javascript" src="/js/TweenMax.min.js"></script>
    <script type="text/javascript" src="/js/flowtype.js"></script>
    <script type="text/javascript" src="/js/script.js"></script>


    <title></title>
</head>
<body onload="draw()">

<div id="mainWrapper">
    <div id="header" >
        <span data-hover="ریــشه">ریــشه</span>
    </div>

    <div id="mobileText">
        <div>
            <h2 style="font-family: BTitrTGEBold ; color: #ED472D">اپلیکیــشن مـوبایــل</h2>
                <p>دسترسی سریع ، لذت بخش بودن کار با آنها و قابل حمل و نقل بودنشان موجب شده تا کمتر خانواده ای را ببینیم که یک موبایل یا تبلت هوشمند نداشته باشد ، تیم طراحی اپلیکیشن ریشه به شما در طراحی یک نرم افزار کار آمد و محبوب کمک خواهد کرد . </p>
        </div>
    </div>
    <div id="webText">
        <div>
            <h2 style="font-family: BTitrTGEBold ; color: #ED472D " >طراحی وبسایت</h2>
                <p>یک طراحی وب خوب میتواند به رشد یک موضوع بسیار کمک کند . طراحی وب اصولی ترکیبی از روانشناسی و علم تجارت و کامپیوتر است .
                    با توجه به رشد سریع تکنولوژی و در دسترس بودن اینترنت ، پر واضح است که یکی از بازار های بزرگ دنیا در حال حاضر بازار اینترنت است .
                    تیم طراحی ریشه امیدوار است با توجه به دارا بودن افراد متخصص و با تجربه بتواند نیاز های شما را در این زمینه تامین نماید .</p>
        </div>
    </div>

    <canvas id="drawSpace"  height="1400">
    </canvas>

    <div id="mobile">
        <div>
            <div id="one"></div>
            <div id="two"></div>
            <div id="three"></div>
            <i class="icon icon-tablet"></i>
        </div>
        <div>
            <div id="four"></div>
            <div id="five"></div>
            <i class="icon icon-mobile"></i>
        </div>
        <div>
            <div id="six"></div>
            <div id="seven"></div>
            <div id="eight"></div>
            <div id="nine"></div>
            <i class="icon icon-mobile2"></i>
        </div>
        <!--<div class="text">-->
        <!--دسترسی سریع ، لذت بخش بودن کار با آنها و قابل حمل و نقل بودنشان موجب شده تا کمتر خانواده ای را ببینیم که یک موبایل یا تبلت هوشمند نداشته باشد ، تیم طراحی اپلیکیشن ریشه به شما در طراحی یک نرم افزار کار آمد و محبوب کمک خواهد کرد-->
        <!--</div>-->
    </div>

    <div id="web">
        <div><i id="html" class="icon icon-html5"></i> </div>
        <div><i id="css" class="icon icon-css3"></i> </div>
        <div><i id="opera" class="icon icon-opera"></i> </div>
    </div>

    <div id="footer">
        <div id="logo"><img src="6.png"></div>
        <h1>گروه توسعه نرم افزار<strong> ریشه</strong></h1>

        <!--<div id="work">-->
        <!--<h1 align="center" style="font-family: BTitrTGEBold">کار هایی که بهشون افتخار میکنیم</h1>-->

        <!--</div>-->


    </div>


</div>




</body>
</html>