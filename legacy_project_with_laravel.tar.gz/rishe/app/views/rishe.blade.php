<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Rishe | ریشه</title>
    <meta charset="utf-8">
    <meta name="description" content="طراحی انواع سایت و اپلیکیشن موبایل و نرم افزار کامپیوتری">
    <meta name="keywords" content="برنامه,سایت, طراجی, توسعه, اندروید,نرم افزار,iOs,Android,website,design,">
    <meta name="alexaVerifyID" content="rGNEH21uGHVgyEDKZO3PgHCvLOQ"/>
    <link rel="icon" href="/img/favicon.png">
    <link rel="stylesheet" href="/css/rishe.css" />
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<div class="load">
    <img src="img/load.gif">
    <div id="BAR" class="bar">
        <small style="font-size:0.6em; font-family: 'Mitra', sans">لطفا منتظر بمانید</small>
    </div>
</div>
<div id="fullpage">
    <div id="one"class="section">
        <div class="menu">
            <ul dir="rtl">
                <li><a href="#about">درباره ما</a></li>
                <li><a href="#web">طراحی سایت</a></li>
                <li><a href="#mobileApp">طراحی نرم افزار موبایل</a></li>
                <li><a href="#desktop">طراحی دیگر برنامه ها</a></li>
                <li><a href="#contact">تماس با ما</a></li>
            </ul>
        </div>
        <div class="text">

            <div class="content">
                <h1>گروه طراحی و توسعه نرم افزار ریشه</h1>
                <h2> بهترین ارائه کننده انواع وبسایت ها، نرم افزارها و سرویس های کامپیوتری به سفارش شما تحت تمامی پلتفرم های رایج.</h2>
                ما آماده ایم که نیاز های شما را در زمینه ی فناوری اطلاعات برآورده کنیم.
                 حتی اگه دقیقا نمیدونید چی میخواین، کافیه سفارش خودتون رو ثبت کنید تا مشاورین ما با شما تماس بگیرن،
                تا مناسب ترین سفارش برای خود را دهید
                ;)

            </div>
            <section class="logo"></section>
        </div>
    </div>


    <div id="two" class="section">
        <div class="aboutUs">
            <h1>آخرین محصول ما</h1>
            <div class="productes">
                <div style="float: left; width: 40%">
                    <h2>شاه کلید</h2>
                    <img src="/img/shahkilid_icon.png" style="height: 200px;">
                </div>
                <h3>اپلیکیشن اندورید شاه کلید هم اکنون در کافه بازار!</h3>
                <p style="text-align: right">
                نرم افزار باز کردن قفل موبایل و تبلت...<br>
                در دنیا امروز بسیار عاقلانه است که روی تلفن همراه خود یک رمز عبور قرار دهیم تا اگر به دست آدم های غیر مرتبط افتاد اطلاعات ما محفوظ بماند. اما فراموش کردن رمز تلفن همراه میتواند یک مشکل خیلی بزرگ باشد که باعث از دست رفتن همه ی اطلاعاتی که روی تلفن همراه خود دارید می شود.
                اپلیکیشن شاه کلید یک راه حل عملی برای این مشکل است! با در اختیار داشتن این برنامه هر گاه رمز خود را فراموش کردید می توانید با یک پیامک رمز گوشی خود را باز کنید!!!<br>
                کافیست شاه کلید را نصب و فعال کنید و شماره ی یک فرد مورد اعتماد را در آن وارد کنید تا از آن پس هرگاه رمز خود را فراموش کردید از آن فرد مورد اعتماد بخواهید که به خط شما یک پیامک با متن Baz sho... بفرستد تا قفل گوشی شما باز شود!!!<br>
                </p>
                <a href="http://cafebazaar.ir/panel/edit/co.rishe.shahkelid.shahkelid/?l=fa">
                <img src="/img/shahkilid_qr.png" style="width: 100px">
                </a>
            </div>
        </div>
    </div>
    <div id="three" class="section">
        <!-- <img class="imac"src="img/imac.png"> -->
        <div class="web">
            <h1>طراحی وبسایت</h1>
            <div class="content" id="website-text">
                <h2>  سفارش هر وبسایتی که شما میخواهید!!!</h2>
                امروزه داشتن یک وبسایت میتواند موجب رشد و رونق در کسب و کار شما و حتی داشتن یک کسب و کار جدید شود.
                سفارش خود را ثبت کنید تا ما مناسب ترین وبسایت را با استفاده از متود های روز جهان برای شما طراحی کنیم.
                تمامی امکانات سایت به انتخاب شما خواهد بود
                و میتوانید یک سایت ساده یا یک سایت بسیار خاص زا سفارش دهید.
<!--                <br><br>-->
<!--                <h3>برای ثبت سفارش مشاهده ی جزئیات و مشاهده ی تعرفه ها و قیمت کلیک کنید:</h3>-->
<!--                <a href="/order#web"><button>ثبت سفارش | مشاهده جزئیات</button></a>-->
            </div>
            <!--div id="cheap" class="pack">
                <h2>بسته اقتصادی</h2>
                <p>بهترین بسته برای کسانی که میخواهند در زمانی بسیار کوتاه و هزینه ی مالی کم صاحب یک وبسایت برای خود یا برای ارزه ی محصولات و خدمات خود باشند</p>
                <a href="#pack1">توضیحات بیشتر</a>
            </div>

            <div id="pro" class="pack">
                <h2>بسته حرفه ای</h2>
                <p>بهترین بسته برای شمایی که به دنبال یک سایت حرفه و خاص هستید.
                تا مخاطبان خود را تحت تاثیر قرار دهید.
                </p>
                <a href="#pack1">توضیحات بیشتر</a>
            </div-->
        </div>
    </div>
    <div id="four" class="section">
        <div class="app">
            <h1>طراحی اپلیکیشن موبایل و تبلت</h1>
            <div class="images">
                <img id="iphone" src="/img/iphone.png">
                <img id="nexus" src="/img/nexus.png">
            </div>
            <div class="apptext">
                امروزه بسیاری از مردم سراسر دنیا از گوشی های هوشمند یا همان
                Smart Phone
                استفاده میکنند.
                این امر موجب شده تا بازار پر از متقاضی در زمینه ی گوشی های هوشمند بوجود آید،
              که میتواند زمینه ی بزرگی برای توسعه ی کسب و کار شما باشد.
                <br>
                کافی است که سفارش خود را با ما در میان بگذارید تا
                ما در کوتاه ترین زمان ممکن اپلیکیشن مورد نیاز شما را با ظاهر و کیفیت خوب برای پاتفرم های
                Android
                و
                iOS
                طراحی کنیم.

<!--                <a href="/order#mobile"><button>ثبت سفارش | مشاهده جزئیات</button></a>-->
            </div>
        </div>
    </div>
    <div id="five" class="section">
        <div class="os">
            <div class="imgs">
                <img src="img/osx.png">
                <img src="img/win.png">
                <img src="img/linux.png">
            </div>
            <div class="text">
                امروزه لزوم استفاده از کامپیوتر در ادارات و شرکت ها با توجه به نقش اساسی آن انکار ناپذیر است .<br>
                هر چند که دنیا در حال حرکت به سمت برنامه های تحت وب است اما نمیتوان نقش برنامه های تحت سیستم عامل نظیر برنامه های حسابداری یا مدیریتی را نادیده گرفت<br>
                تیم ریشه میتواند به شما در دست یافتن به برنامه ی مورد نظرتان یاری برساند
<!--                <br>-->
<!--                <a href="/order#mobile"><button>ثبت سفارش | مشاهده جزئیات</button></a>-->
            </div>
        </div>
    </div>
    <div id="six" class="section">
        <div class="contact">
            <p><img src="img/rishe-logo.png"></p>
            <p>Email: <small>info@rishe.co</small></p>
<!--            <p>Tell: <small>123-12345678</small></p>-->
            <p>Facebook: <a href="https://www.facebook.com/rishe.co"><small>fb.com/rishe.co</small></a></p>
            <div id="facebook">
                <br>
                <br>
                <table>
                    <tr>
                        <td colspan="2"><span>
                            برای با خبر شدن از آخرین محصولات
                            ،
                            ما را در شبکه های اجتماعی دنبال کنید :)
                            </span></td>
                    </tr>
                    <tr>
                        <td><small>Facebook</small></td>
                        <td><small>Google</small></td>
                    </tr>
                    <tr>
                        <td><div class="fb-like" data-href="https://www.facebook.com/rishe.co" data-width="50" data-layout="button" data-action="like" data-show-faces="true" data-share="false"></div></td>
                        <td><div class="g-plusone"></div></td>
                    </tr>
                </table>
            </div>


        </div>
    </div>
</div>

<!-- <script src="js/jquery-1.11.1.js"></script>
<script src="js/jquery-ui-1.9.2.custom.min.js"></script>
 -->
<link rel="stylesheet" type="text/css" href="css/jquery.fullPage.css" />

<script src="/js/analytics.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>

<script src="js/jquery.flatshadow.min.js"></script>
<script src="js/flowtype.js"></script>
<script type="text/javascript" src="js/jquery.slimscroll.min.js"></script>

<script type="text/javascript" src="js/jquery.fullPage.js"></script>

<script>
    $(document).ready(function(){
        $(window).load(function(){
            $('div.load').fadeOut();
        });

        $('div#three').css('background-position','-'+(window.innerWidth) +'px');
    })
</script>

<script type="text/javascript">
    function blurElement(element, size){
        var filterVal = 'blur('+size+'px)';
        $(element)
            .css('filter',filterVal)
            .css('webkitFilter',filterVal)
            .css('mozFilter',filterVal)
            .css('oFilter',filterVal)
            .css('msFilter',filterVal);
    }

    blurElement('section',10);
    function hideBlur(element){ var time = setInterval(blurElement(element),1000); }


    var firsText = document.getElementsByClassName('text')[0];
    var margin = (window.innerHeight - firsText.offsetHeight)/4 ;
    firsText.setAttribute('style','margin-top:'+ margin + 'px;')

    var logoWidth = document.getElementsByClassName('logo')[0].offsetWidth ;

    document.getElementsByClassName('logo')[0].setAttribute('style','height:'+logoWidth+'px;');

    //animate
    var text  = document.getElementsByClassName('content')[0];
    var logo = document.getElementsByClassName('logo')[0];
    text.setAttribute('style','margin-right:-150px;opacity:0;');

    function move(elem) {
        var left = 0
        function frame() {
            left++  // update parameters

            var opacity = Number(window.getComputedStyle(text).opacity) + 0.007;
            var margin = parseInt(window.getComputedStyle(text).marginRight) + 1;

            text.setAttribute('style','margin-right:'+margin+'px;'+'opacity:'+opacity+';'); // show frame
            if (left == 150)  // check finish condition
                clearInterval(id)
        }
        var id = setInterval(frame, 10) // draw every 10ms
    }
    move();
    //end



    window.onresize = function(){
        var logoWidth = document.getElementsByClassName('logo')[0].offsetWidth ;
        console.log(logoWidth);
        document.getElementsByClassName('logo')[0].setAttribute('style','height:'+logoWidth+'px;');
    }
    $('body').flowtype({
        minimum   : 500,
        maximum   : 1200,
        minFont   : 12,
        maxFont   : 24,
        fontRatio : 85
    });



    //loading



    //end
</script>
<script>
    $(document).ready(function() {

        $('#fullpage').fullpage({
            verticalCentered: false,
            resize : true,
            sectionsColor : ['#3498db','#700029','#2ecc71','#34495e','#e67e22','#16a085'],
            anchors:['home', 'about','web','mobileApp','desktop','contact'],
            scrollingSpeed: 700,
            easing: 'easeInQuart',
            menu: true,
            navigation: true,
            navigationPosition: 'right',
            navigationTooltips: ['صفحه اصلی', 'درباره ما','طراحی وبسایت','طراحی نرم افزار موبایل','طراحی نرم افزار سیستم عامل','تماس با ما'],
            slidesNavigation: true,
            slidesNavPosition: 'bottom',
            loopBottom: true,
            loopTop: false,
            loopHorizontal: true,
            autoScrolling: true,
            scrollOverflow: false,
            css3: false,
            paddingTop: '0px',
            paddingBottom: '0px',
            normalScrollElements: '#element1, .element2',
            normalScrollElementTouchThreshold: 2,
            keyboardScrolling: true,
            touchSensitivity: 15,
            continuousVertical: false,
            animateAnchor: true,
            sectionSelector: '.section',
            slideSelector: '.slide',

            //events
            onLeave: function(index, nextIndex, direction){
                if(index == 2){
                    $('div.aboutUs div.img img').animate({'opacity':0,'margin-left':'15px'},700);
                    $('div.aboutUs div.img p').delay(500).animate({'opacity':0});
                }
                if(index == 3){
                    $('div#three	').animate({'background-position':'-'+(window.innerWidth) +'px'},700);
                    $('div.pack').animate({'opacity':0});
                }
                if(index == 4){
                    $('div#four img').animate({'margin-left':'0%'},700);

                }
                if(index == 5){
                    $('div#five img').animate({'opacity':0},700);

                }
            },
            afterLoad: function(anchorLink, index){
                if(anchorLink == 'about'){
                    $('div.aboutUs div.img img').animate({'opacity':1,'margin-left':'0px'},700);
                    $('div.aboutUs div.img p').delay(500).animate({'opacity':1});
                }
                if(anchorLink == 'web'){
                    $('div#three').animate({'background-position':'-'+(window.innerWidth/2) +'px'},700);
                    $('div.pack').delay(700).animate({'opacity':1});
                }
                if(anchorLink == 'mobileApp'){
                    $('div#four img').animate({'margin-left':'-10%'},700);

                }
                if(anchorLink == 'desktop'){
                    $('div#five img').animate({'opacity':1},700);

                }
            },
            afterRender: function(){},
            afterResize: function(){},
            afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex){},
            onSlideLeave: function(anchorLink, index, slideIndex, direction){}
        });
    });
</script>
<script src="https://apis.google.com/js/platform.js" async defer>
    {lang: 'fa'}
</script>
</body>
</html>