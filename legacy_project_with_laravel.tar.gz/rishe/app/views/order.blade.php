<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Rishe | ریشه</title>
    <meta charset="utf-8">
    <meta title="Rishe | ریشه">
    <meta name="description" content="سفارش طراحی سایت و اپلیکیشن موبایل">
    <meta name="keywords" content="برنامه,سایت, طراجی, توسعه, اندروید,نرم افزار,iOS,Android,website,design,">
    <link rel="icon" href="/img/favicon.png">
    <link rel="stylesheet" href="/css/order.css" />
</head>
<body>
<div class="select">
    <select>
        <option>طراحی سایت</option>
        <option>نرم افزار موبایل</option>
        <option>نرم افزار کامپیوتر</option>
    </select>
</div>
<h1>ثبت سفارش</h1>
<div class="packages">
    <h2>بسته های پیشنهادی:</h2>
    <p class="content">
    برای راحتی شما، در انتخاب چند بسته ی پر متقاضی را برای شما تعبیه کردیم
        ،
        شما میتواینید از بین آنها بسته مناسب برای خود را انتخاب کنید و به راحتی سفارش دهید
         و منتطر بمانید تا کارشناسان ما برای جزئیات بیشتر با شما تماس بگیرند.
    </p>
    <div class="slide-show">
        <div style="display:table;width:100%;">
            <div style="display:table-row">

                <div class="package">
                    <h2>بسته اقتصادی</h2>
                    <img src="http://3.bp.blogspot.com/_f-jfbjsumsM/S_XqpLb7mBI/AAAAAAAAACI/3mxXZI7PDqg/s1600/green4.jpg">
                    <p>
                        این بسته برای کسانی مناسب است که اوسکلن
                    </p>
                    <button class="select">انتخاب</button>
                </div>
                <div class="package"><button class="select">انتخاب</button></div>
                <div class="package"><button class="select">انتخاب</button></div>

            </div>
        </div>
    </div>
    <form>
    <div class="title">
        <h2>تنظیمات بیشتر (اختیاری):</h2>
        <div class="detail">
            <table>
                <tbody>
                <tr><td colspan="5"><small>خدمات راه اندازی سایت:</small></td></tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>خدمات دامنه</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات هاستینگ</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات سرور مجازی</label></td>
                    <td><input type="checkbox" id="1"><label>راه اندازی ایمیل</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات فرستادن ایمیل های انبوه</label></td>
                </tr>
                <tr><td colspan="5" class="title"><hr></td></tr>
                <tr><td colspan="5"><small>خدمات طراحی سایت</small></td></tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>سایت داینامیک</label></td>
                    <td><input type="checkbox" id="1"><label>سایت استاسیک</label></td>
                    <td><input type="checkbox" id="1"><label>ثبت نام کاربر</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات rss</label></td>
                    <td><input type="checkbox" id="1"><label>طراحی API های سفارشی</label></td>
                </tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>سیستم مدریت محتوای آماده</label></td>
                    <td><input type="checkbox" id="1"><label>سیستم مدریت محتوای سفارشی</label></td>
                    <td><input type="checkbox" id="1"><label>CSS سفارشی</label></td>
                    <td><input type="checkbox" id="1"><label>CSS با Bootstrap</label></td>
                    <td><input type="checkbox" id="1"><label>استفاده از قالب آماده</label></td>
                </tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>جلوه های گرافیکی با jQuery</label></td>
                    <td><input type="checkbox" id="1"><label>JavaScript و Ajax</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات عکاسی تبلیغاتی</label></td>
                    <td><input type="checkbox" id="1"><label>عکس های سفارشی</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات تخصصی طراحی</label></td>
                </tr>
                <tr><td colspan="5" class="title"><hr></td></tr>
                <tr><td colspan="5"><small>خدمات بهینه سازی سایت:</small></td></tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>OAuth</label></td>
                    <td><input type="checkbox" id="1"><label>Google Analytics</label></td>
                    <td><input type="checkbox" id="1"><label>Social networks APIs</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات شبکه های اجتماعی</label></td>
                    <td><input type="checkbox" id="1"><label>خدمات SEO</label></td>
                </tr>
                <tr><td colspan="5" class="title"><hr></td></tr>
                <tr><td colspan="5"><small>خدمات جانبی:</small></td></tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>خدمات فزستادن SMS</label></td>
                    <td><input type="checkbox" id="1"><label>سرور دریافت SMS</label></td>
                    <td><input type="checkbox" id="1"><label>اپلیکیشن Android</label></td>
                    <td><input type="checkbox" id="1"><label>اپلیکیشن iOS</label></td>
                    <td><input type="checkbox" id="1"><label>پرداخت اینترنتی و درگاه بانکی</label></td>
                </tr>
                <tr><td colspan="5" class="title"><hr></td></tr>
                <tr><td colspan="5"><small>زبان سرور ساید سایت:</small></td></tr>
                <tr>
                    <td><input type="checkbox" id="1"><label>php</label></td>
                    <td><input type="checkbox" id="1"><label>C# ASP.Net</label></td>
                    <td><input type="checkbox" id="1"><label>Node.js</label></td>
                    <td><input type="checkbox" id="1"><label>Python Django</label></td>
                    <td><input type="checkbox" id="1"><label>Java</label></td>
                </tr>
                </tbody>
            </table>
        </div>
        <h4>این بخش برای کسانی است که روی سفارش خود دقیق اند</h4>
    </div>
    <div id="div-price">
    هزینه ی تخمین زده شده:‌<strong>300,000</strong> تومان
    </div>
    <div class="title">
        <h2>مشخصات شما:</h2>
        <div class="detail">
            <div class="form">
                <table><tbody>
                    <tr><td colspan="2"><input id="name" class="text" placeholder="نام و نام خانوادگی"></td> </tr>
                    <tr><td><input id="tel1" class="text" placeholder="شماره تماس" type="tel"></td>
                    <td><input id="tel2" class="text" placeholder="شماره تماس ۲" type="tel"></td></tr>
                    <tr><td colspan="2"><input id="email" class="text" placeholder="ایمیل" type="email"></td> </tr>
                    <tr><td colspan="2"><textarea id="info" class="text" placeholder="توضیحات شما"></textarea></td> </tr>
                </tbody></table>

            </div>
        </div>
        <h4>این بخش را با دقت پر کنید</h4>
    </div>
        <input type="submit" value="ثبت سفارش" class="submit">
    </form>
    <div class="footer">

    </div>
</div>
<script src="/js/analytics.js"></script>
<script>
    alert("این صفحه هنوز تکمیل نشده است\n در دست احداث")
</script>
</body>