<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Rishe | ریشه</title>
    <meta charset="utf-8">
    <meta title="Rishe | ریشه">
    <meta name="description" content="سفارش طراحی سایت و اپلیکیشن موبایل">
    <meta name="keywords" content="برنامه,سایت, طراجی, توسعه, اندروید,نرم افزار,iOS,Android,website,design,">
    <link rel="icon" href="/img/favicon.png">
    <link rel="stylesheet" href="/css/order.css" />
</head>
<body>
    <div class="popup">
        <div class="right">

        </div>
        <img src="http://3.bp.blogspot.com/_f-jfbjsumsM/S_XqpLb7mBI/AAAAAAAAACI/3mxXZI7PDqg/s1600/green4.jpg">
    </div>
<style>
    body{
        background: #3f3f3f;
        padding: 20px;
    }
    div.popup{
        width: 400px;
        height: 200px;
        background: #ffffff;
        border-radius: 5px;
        float: right;
    }
    div.right{
        float: right;
    }
    img{
        float: left;
        width: 200px;
    }
</style>
</body>